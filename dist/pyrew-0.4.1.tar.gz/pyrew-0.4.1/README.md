# Pyrew

Welcome to Pyrew (PYthon REWrite), a Python program that provides the ability to write shorter and more efficient Python code by simply downloading, installing and importing a single file.

## Installation

1. Run the following command:

```
pip install git+https://github.com/AquaQuokka/pyrew.git
```

2. At the top of your file, add the following code:

```py
import pyrew

pyrew = pyrew.Pyrew()
```